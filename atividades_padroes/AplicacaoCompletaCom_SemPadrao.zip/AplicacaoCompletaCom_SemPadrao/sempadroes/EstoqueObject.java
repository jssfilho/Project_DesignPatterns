/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sempadroes;

/**
 *
 * @author joao
 */
public class EstoqueObject extends Estoque{

    public EstoqueObject(float preco, int cod, String nome, String marca) {
        super(preco, cod, nome, marca);
    }

    @Override
    public void addProd(Produto p) {
        System.out.println("Produto adicionado");
    }

    @Override
    public void remProd(Produto p) {
        System.out.println("Produto removido");
    }
    
}
