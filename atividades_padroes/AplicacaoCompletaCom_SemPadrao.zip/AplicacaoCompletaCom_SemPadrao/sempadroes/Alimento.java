
package sempadroes;

/*
 * @author joao
 */
public class Alimento {
    
}
