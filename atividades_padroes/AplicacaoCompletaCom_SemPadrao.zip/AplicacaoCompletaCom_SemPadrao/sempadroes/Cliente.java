
package sempadroes;

import java.util.Date;

/*
 * @author joao
 */
public class Cliente {
    private String cpf;
    private String nome;
    private Date dataNasc;

    public Cliente(String cpf, String nome, Date dataNasc) {
        this.cpf = cpf;
        this.nome = nome;
        this.dataNasc = dataNasc;
    }
    
    public void comprar(Venda v,String numCard,String senha,String tipPag){
        v.pagamento(numCard, tipPag,senha);
    }

    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public Date getDataNasc() {
        return dataNasc;
    }

    public void setDataNasc(Date dataNasc) {
        this.dataNasc = dataNasc;
    }

    
}
