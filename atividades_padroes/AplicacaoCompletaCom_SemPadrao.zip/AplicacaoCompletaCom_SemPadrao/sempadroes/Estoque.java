/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sempadroes;

/*
 * @author joao
 */
public abstract class Estoque extends Produto{
    
    public Estoque(float preco, int cod, String nome, String marca) {
        super(preco, cod, nome, marca);
    }
    public abstract void addProd(Produto p);
    public abstract void remProd(Produto p);
}
