/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sempadroes;

/*
 * @author João Santos
 */
public class Produto {
    protected float preco;
    protected int cod;
    protected String nome;
    protected String marca;

    public Produto(float preco, int cod, String nome, String marca) {
        this.preco = preco;
        this.cod = cod;
        this.nome = nome;
        this.marca = marca;
    }
    
    
    public void remProduto(int cod){
        System.out.println("Produto de Codigo: "+cod+"removido!");
    }

    public float getPreco() {
        return preco;
    }

    @Override
    public String toString() {
        return "Produto{" + "preco=" + preco + ", cod=" + cod + ", nome=" + nome + ", marca=" + marca + '}';
    }
    
    public void setPreco(float preco) {
        this.preco = preco;
    }

    public int getCod() {
        return cod;
    }

    public void setCod(int cod) {
        this.cod = cod;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }
    
    
}
