
package sempadroes;

/*
 * @author joao
 */
public class EstoqueBD extends Estoque {

    public EstoqueBD(float preco, int cod, String nome, String marca) {
        super(preco, cod, nome, marca);
    }
    
    @Override
    public void addProd(Produto p) {
        System.out.println("Produto adicionado");
    }

    @Override
    public void remProd(Produto p) {
        System.out.println("Produto removido");
    }
}
