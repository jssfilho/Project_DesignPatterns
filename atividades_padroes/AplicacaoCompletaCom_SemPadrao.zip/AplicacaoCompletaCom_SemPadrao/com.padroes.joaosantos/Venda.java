package br.padroes;

import java.util.ArrayList;

/*
 * @author João Santos
 */
public class Venda {
    protected final ArrayList<Produto> carrinho = new ArrayList();
    protected float valorVenda=0;
    protected String cardDinheiro;
    
    public Venda(){
        
    }
     
    public void pagamento(String numCard, String debCred, String senha){
        this.cardDinheiro="Cartão";
        System.out.println("Pagamento Efetuado");
    }
    
    public void addProd(Produto prod){
        this.carrinho.add(prod);
        this.valorVenda+=prod.getPreco();
        System.out.println("Produto Adicionado");
    }
    public void remProd(Produto prod){
        this.carrinho.remove(prod);
        this.valorVenda-=prod.getPreco();
        System.out.println("Produto Removido");
    }
    public Produto getProduto(int cod){
        Produto p = null;
        for(Produto prod: carrinho){
            if(cod==prod.getCod())
                p=prod;
        }
        
        return p;
    }

    public float getValorVenda() {
        return valorVenda;
    }
    
    public String getCardDinheiro() {
        return cardDinheiro;
    }

    public void setCardDinheiro(String cardDinheiro) {
        this.cardDinheiro = cardDinheiro;
    }
    
    
}
