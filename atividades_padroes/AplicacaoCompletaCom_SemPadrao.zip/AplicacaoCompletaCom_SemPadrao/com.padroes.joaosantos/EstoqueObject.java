
package br.padroes;
/*
 * @author joao
 */
public class EstoqueObject implements EstoqueImplementacao {

    @Override
    public Produto getProduto(){
        Produto p = null;
        return p;
    }

    @Override
    public void registroProduto(Produto p) {
        System.out.println("Produto Registrado.");
    }
    
}
