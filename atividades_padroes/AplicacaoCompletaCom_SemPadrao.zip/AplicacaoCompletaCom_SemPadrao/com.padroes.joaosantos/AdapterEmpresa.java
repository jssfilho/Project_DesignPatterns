/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.padroes;

/**
 *
 * @author João Santos
 */
public class AdapterEmpresa extends Venda implements AlvoEmpresa{
    private float valor;

    public AdapterEmpresa() {
    }

    public void setValor(float valor) {
        this.valor = valor;
    }
    
    @Override
    public void pagamentoCardEmpresa(String num) {
        this.cardDinheiro="cardEmpresa";
        System.out.println("Pagamento Efetuado.");
    }
}
