/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.padroes;

/**
 *
 * @author joao
 */
public class EstoqueBD implements EstoqueImplementacao{

    @Override
    public Produto getProduto() {
        Alimento p = null;
        return p;
    }

    @Override
    public void registroProduto(Produto p) {
        System.out.println("Produto Registrado!");
    }
    
}
