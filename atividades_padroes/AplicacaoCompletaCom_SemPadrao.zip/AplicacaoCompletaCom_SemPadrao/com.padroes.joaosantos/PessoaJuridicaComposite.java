
package br.padroes;

import java.util.ArrayList;

/*
 * @author João Santos
 */
public class PessoaJuridicaComposite extends ClienteComponente {
    private final ArrayList <ClienteComponente> autorizadasCompras = new ArrayList();
    private String cnpj;
    private PessoaFisicaFolha responsavel;
    private String cardEmpresa;
    
    public PessoaJuridicaComposite(String cnpj, PessoaFisicaFolha responsavel) {
        this.cnpj = cnpj;
        this.responsavel = responsavel;
        this.autorizadasCompras.add(responsavel);
    }
    public void comprar(AdapterEmpresa v){
        v.pagamentoCardEmpresa(this.cardEmpresa);
    }
    
    public void addAutorizado(PessoaFisicaFolha pf){
        this.autorizadasCompras.add(pf);
    }
    public void remAutorizado(String cpf){
        for(ClienteComponente p: this.autorizadasCompras){
            if(cpf.equals(p.getCod())){
                this.autorizadasCompras.remove(p);
            }
        }
    }

    @Override
    public String getCod() {
        return this.cnpj;
    }

}
