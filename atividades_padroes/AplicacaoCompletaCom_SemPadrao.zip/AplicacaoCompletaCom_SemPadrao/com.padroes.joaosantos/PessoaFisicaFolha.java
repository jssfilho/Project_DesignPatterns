/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.padroes;

import java.util.Date;

/*
 * @author João Santos
 */
public class PessoaFisicaFolha extends ClienteComponente{
    private String cpf;
    private Date nascimento;
    
    public PessoaFisicaFolha(){
        
    }
    
    public PessoaFisicaFolha(String cpf, Date nascimento) {
        this.cpf = cpf;
        this.nascimento = nascimento;
    }
    
    public void comprar(Venda v, String card, String debCred, String senha){
        v.pagamento(card, debCred, senha);
    }

    
    @Override
    public String getCod() {
        return this.cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    public Date getNascimento() {
        return nascimento;
    }

    public void setNascimento(Date nascimento) {
        this.nascimento = nascimento;
    }
    
}
