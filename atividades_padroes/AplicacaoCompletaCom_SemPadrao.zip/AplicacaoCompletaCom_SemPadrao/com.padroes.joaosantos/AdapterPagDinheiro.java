
package br.padroes;

/*
 * @author João Santos
 */
public class AdapterPagDinheiro extends Venda implements AlvoPagDinheiro{
    private float valor;
    
    public AdapterPagDinheiro() {
    }
    @Override
    public float pagamento(float valorRecebido) {
        this.cardDinheiro="Dinheiro";
        float troco = valorRecebido-this.valorVenda;
        System.out.printf("Pagamento Efetuado. Troco: R$ %.2f",(troco));
        return troco;
    } 

    public float getValor() {
        return valor;
    }

    public void setValor(float valor) {
        this.valor = valor;
    }
    
}
