
package br.padroes;

/*
 * @author João Santos
 */
public interface EstoqueImplementacao {
    public Produto getProduto();
    public void registroProduto(Produto p);
    
}
