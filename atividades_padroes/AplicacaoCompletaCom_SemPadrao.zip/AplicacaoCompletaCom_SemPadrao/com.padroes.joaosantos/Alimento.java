
package br.padroes;

import java.util.Date;

/*
 * @author joao
 */
public class Alimento extends Produto {
    private final Date dataValidade;
    
    public Alimento(float preco, int cod, String nome, String marca, Date validade) {
        super(preco, cod, nome, marca);
        this.dataValidade=validade;
    }
    
}
