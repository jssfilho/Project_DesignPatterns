
package br.padroes;
/*
 * @author João Santos
 */
public class Aplicacao {
    public static void main(String[] args) {
        
    }
    
}
