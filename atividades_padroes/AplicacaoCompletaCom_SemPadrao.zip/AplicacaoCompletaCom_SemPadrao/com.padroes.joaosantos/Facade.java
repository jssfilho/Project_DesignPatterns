
package br.padroes;
/*
 * @author João Santos
 */
public class Facade {
    private final Venda v = new Venda();
    
    public void pagamentoEmpresa(PessoaJuridicaComposite p){
        AdapterEmpresa aEmp = new AdapterEmpresa();
        aEmp.setValor(this.v.getValorVenda());
        p.comprar(aEmp);
    }
    public float pagamentoDinheiro(PessoaFisicaFolha p, float valorRecebido){
        AdapterPagDinheiro pagDim= new AdapterPagDinheiro();
        pagDim.setCardDinheiro("Dinheiro");
        pagDim.setValor(this.v.getValorVenda());
        return pagDim.pagamento(valorRecebido);
    }
    public void pagamentoCard(PessoaFisicaFolha p, String card, String debCred, String senha){
        p.comprar(this.v, card, debCred, senha);
    }
    public void addProd(Produto prod){
        v.addProd(prod);
    }
    public void remProd(int cod){
        this.v.remProd(this.v.getProduto(cod));
    }
}
