
package br.padroes;

/*
 * @author João Santos
 */
public class Eletronico extends Produto {
    
    public Eletronico(float preco, int cod, String nome, String marca) {
        super(preco, cod, nome, marca);
        
    }
}
