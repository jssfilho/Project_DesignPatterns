
package br.padroes;

/*
 * @author João Santos
 * AlvoPagDinheiro em Adapter
 */
public interface AlvoPagDinheiro {
    public float pagamento(float valorRecebido);
}
